> getwd()
[1] "D:/�������/Homework1"
> attach(FinancialData)
> names(FinancialData)
[1] "GVKEY"                  "datadate"              
[3] "fyear"                  "conm"                  
[5] "che"                    "cogs"                  
[7] "csho"                   "dlc"                   
[9] "dltt"                   "ebit"                  
[11] "ebitda"                 "earnings.per.share"    
[13] "ni"                     "costat"                
[15] "stock.price"            "market.value.of.equity"
[17] "equity.value"           "X"                     
> plot(ebitda,earnings.per.share)
> cor(ebitda,earnings.per.share)
[1] NA
> cor(ebitda,stock.price)
[1] NA
> plot(ebitda,stock.price)
> cor(ebitda,market.value.of.equity)
[1] NA
> plot(ebitda,market.value.of.equity)
> cor(ebitda,equity.value)
[1] NA
> plot(ebitda,equity.value)
> cor(earnings.per.share,stock.price)
[1] NA
> plot(earnings.per.share,stock.price)
> cor(earnings.per.share,market.value.of.equity)
[1] NA
> plot(earnings.per.share,market.value.of.equity)
> cor(earnings.per.share,equity.value)
[1] NA
> plot(earnings.per.share,equity.value)
> cor(stock.price,market.value.of.equity)
[1] NA
> plot(stock.price,market.value.of.equity)
> cor(market.value.of.equity,equity.value)
[1] NA
> plot(market.value.of.equity,equity.value)