> getwd()
[1] "C:/Users/User/Documents"
> setwd("D:/�������/Homework1")
> casesdata<-read.csv('casesdata.csv',header=TRUE)
> attach(casesdata)
> names(casesdata)
[1] "Province.State"       "Country.Region"      
[3] "X8.25.20.9.25.20.new" "X9.25.20confirmed"   
[5] "X9.25.20.deaths"     
> class(X8.25.20.9.25.20.new)
[1] "integer"
> class(X9.25.20confirmed)
[1] "integer"
> class(X9.25.20.deaths)
[1] "integer"
> cor(X8.25.20.9.25.20.new,X9.25.20confirmed)
[1] 0.9111658
> cor(X8.25.20.9.25.20.new,X9.25.20.deaths)
[1] 0.7621767
> cor(X9.25.20confirmed,X9.25.20.deaths)
[1] 0.9338897
> plot(X8.25.20.9.25.20.new,X9.25.20confirmed,xlab="new",ylab="confirmed")
> plot(X8.25.20.9.25.20.new,X9.25.20.deaths,xlab="new",ylab="deaths")
> plot(X9.25.20confirmed,X9.25.20.deaths,xlab="confirmed",ylab="deaths")